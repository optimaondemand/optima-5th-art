Week 17
Filename: images/5-17-colosseum.jpg
Title: Ancient Rome
Credit/license: Giovanni Paolo Panini · 1757 · The Metropolitan Museum of Art · Open Access/Public Domain
Source: https://www.metmuseum.org/art/collection/search/437244

Week 18
Filename: images/5-18-piranesi-colosseum.jpg
Title: Colosseum Print Reference
Credit/license: Giovanni Battista Piranesi · 1700s · The Metropolitan Museum of Art · Open Access/Public Domain
Source: https://www.metmuseum.org/art/collection/search?q=Piranesi%20Colosseum&showOnly=openAccess

Week 19
Filename: images/5-19-colosseum-interior.jpg
Title: Colosseum Interior Reference
Credit/license: Roman architecture / print reference · The Metropolitan Museum of Art · Open Access/Public Domain search reference
Source: https://www.metmuseum.org/art/collection/search?q=Piranesi%20Colosseum%20interior&showOnly=openAccess

Week 20
Filename: images/5-20-byzantine-mosaic.jpg
Title: Court of Emperor Justinian with Archbishop Maximian
Credit/license: Basilica of San Vitale mosaic / photo by Roger Culos · c. 547 mosaic · 2015 photograph · Wikimedia Commons · photo by Roger Culos · CC BY-SA 3.0
Source: https://commons.wikimedia.org/wiki/File:Sanvitale03.jpg

Week 21
Filename: images/5-21-illuminated-manuscript.jpg
Title: Illuminated Manuscript Page
Credit/license: Medieval manuscript artists · Middle Ages · public-domain manuscript reference
Source: https://www.metmuseum.org/art/collection/search?q=illuminated%20manuscript&showOnly=openAccess

Week 22
Filename: images/5-22-calligraphy-lettering.jpg
Title: Decorative Lettering Reference
Credit/license: Medieval manuscript illumination · public-domain manuscript reference
Source: https://www.metmuseum.org/art/collection/search?q=illuminated%20initial%20book%20of%20hours&showOnly=openAccess

Week 23
Filename: images/5-23-coat-of-arms.jpg
Title: Heraldic Shields from the Book of Additions
Credit/license: Matthew Paris · c. 1250 · Wikimedia Commons · public domain
Source: https://commons.wikimedia.org/wiki/File:MatthewParis_BookOfAdditions_BritishLibrary.jpg

Week 24
Filename: images/5-24-shield-reference.jpg
Title: Heraldic Shields from the Book of Additions
Credit/license: Matthew Paris · c. 1250 · Wikimedia Commons · public domain
Source: https://commons.wikimedia.org/wiki/File:MatthewParis_BookOfAdditions_BritishLibrary.jpg
