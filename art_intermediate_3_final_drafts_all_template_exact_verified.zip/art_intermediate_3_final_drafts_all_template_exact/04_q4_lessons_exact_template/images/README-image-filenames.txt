Week 25
Filename: images/5-25-blue-willow-pattern.jpg
Title: Willow Pattern
Credit/license: Illustration from The Book of Knowledge · 1912 book illustration · Wikimedia Commons · public domain in the United States
Source: https://commons.wikimedia.org/wiki/File:Willow_Pattern.jpg

Week 26
Filename: images/5-26-basket-of-apples.jpg
Title: The Basket of Apples
Credit/license: Paul Cézanne · 1893 · Art Institute of Chicago / Wikimedia Commons · public domain
Source: https://commons.wikimedia.org/wiki/File:Paul_C%C3%A9zanne_-_The_Basket_of_Apples_-_1926.252_-_Art_Institute_of_Chicago.jpg

Week 27
Filename: images/5-27-bedroom-in-arles.jpg
Title: The Bedroom
Credit/license: Vincent van Gogh · 1889 · Wikimedia Commons · public domain
Source: https://commons.wikimedia.org/wiki/File:Vincent_van_Gogh_-_De_slaapkamer_-_Google_Art_Project.jpg

Week 28
Filename: images/5-28-hunters-in-the-snow.jpg
Title: Hunters in the Snow
Credit/license: Pieter Bruegel the Elder · 1565 · Wikimedia Commons · public domain
Source: https://commons.wikimedia.org/wiki/File:Pieter_Bruegel_the_Elder_-_Hunters_in_the_Snow_(Winter)_-_Google_Art_Project.jpg

Week 29
Filename: images/5-29-childrens-games.jpg
Title: Children’s Games
Credit/license: Pieter Bruegel the Elder · 1560 · Wikimedia Commons / Google Art Project · public domain
Source: https://commons.wikimedia.org/wiki/File:Pieter_Bruegel_the_Elder_-_Children%E2%80%99s_Games_-_Google_Art_Project.jpg

Week 30
Filename: images/5-30-optima-owl-community-symbol.png
Title: Optima Academy Owl Mark
Credit/license: Optima Academy Online · Optima Academy asset used for course identity
Source: https://raw.githubusercontent.com/optimaondemand/optima-assets/eeb0b335630058906d52f478028361d352253a93/images/Optima%20Final%20Circle%20-%20Owl%20Only.png

Week 31
Filename: images/5-31-cabinet-of-curiosities.jpg
Title: Musei Wormiani Historia
Credit/license: Ole Worm / Museum Wormianum · 1655 · Wikimedia Commons · public domain
Source: https://commons.wikimedia.org/wiki/File:Musei_Wormiani_Historia.jpg

Week 32
Filename: images/5-32-gallery-of-the-louvre.jpg
Title: Gallery of the Louvre
Credit/license: Samuel F. B. Morse · 1831–1833 · Wikimedia Commons · public domain
Source: https://commons.wikimedia.org/wiki/File:Gallery_of_the_Louvre_1831-33_Samuel_Morse.jpg
