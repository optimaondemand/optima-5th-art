Week 9
Filename: images/5-09-katagami-stencil.jpg
Title: Japanese Katagami Stencil Geometric Ornament
Credit/license: Japanese stencil artist · via Wikimedia Commons · Public domain
Source: https://commons.wikimedia.org/wiki/File:Japanese_Katagami_Stencil_Geometric_Ornament.jpg

Week 10
Filename: images/5-10-cueva-de-las-manos.jpg
Title: Cueva de las Manos
Credit/license: Ancient cave artists / photo by Marianocecowski · via Wikimedia Commons · CC BY-SA 3.0
Source: https://blog.education.nationalgeographic.org/2013/10/09/were-the-first-artists-mostly-women/

Week 11
Filename: images/5-11-egyptian-cartouche.jpg
Title: Cartouche of Thutmose III
Credit/license: Ancient Egyptian artist · The Metropolitan Museum of Art · Open Access/Public Domain
Source: https://www.metmuseum.org/art/collection/search/553517

Week 12
Filename: images/5-12-lotiform-chalice.jpg
Title: Lotiform Chalice
Credit/license: Ancient Egyptian artist · The Metropolitan Museum of Art · Open Access/Public Domain
Source: https://www.metmuseum.org/art/collection/search/548339

Week 13
Filename: images/5-13-reconstructed-lotiform-chalice.jpg
Title: Reconstructed Lotiform Chalice
Credit/license: Ancient Egyptian artist · The Metropolitan Museum of Art · Open Access/Public Domain
Source: https://www.metmuseum.org/art/collection/search/553649

Week 14
Filename: images/5-14-parthenon-athens.jpg
Title: Parthenon, Athens
Credit/license: Ancient Greek architects / modern public-domain photograph · PublicDomainPictures.net · CC0/Public Domain
Source: https://www.publicdomainpictures.net/en/view-image.php?image=206934&picture=parthenon-athens

Week 15
Filename: images/5-15-panathenaic-amphora.jpg
Title: Panathenaic Prize Amphora
Credit/license: Ancient Greek artist · The Metropolitan Museum of Art · Open Access/Public Domain
Source: https://www.metmuseum.org/art/collection/search/249067

Week 16
Filename: images/5-16-column-orders.jpg
Title: Table of Architecture
Credit/license: Cyclopaedia engraver · 1728 · Wikimedia Commons · Public domain
Source: https://commons.wikimedia.org/wiki/File:Table_of_architecture,_Cyclopaedia,_1728,_volume_1.jpg
